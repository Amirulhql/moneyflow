# MoneyFlow — personal expense tracker

MoneyFlow is a standalone, mobile-friendly, private-first expense tracking web app. No paid service, API key, bank account connection, or build step is required.

## Get started

**Easy desktop trial:** Open `moneyflow-standalone.html` from the separate download in a modern web browser (Chrome, Edge, Firefox, or Safari). It contains all the app code in one HTML file.

**Run the full installable version:** Put the complete folder on an HTTPS static website (for example GitHub Pages, Netlify, or Cloudflare Pages). The main file is `index.html`. For a local development preview, run the following command in this folder:

```bash
python -m http.server 8000
```

Then open `http://localhost:8000/` in your browser. Local development uses HTTP on localhost, which browsers allow for progressive web apps. For real phones, use HTTPS hosting.

**Install on iPhone:** After hosting the full folder over HTTPS, open the site in Safari, tap **Share**, then **Add to Home Screen**. On supported browsers, the service worker makes the full version available offline after it has been opened and cached.

## First use

1. Go to **Settings → Accounts**. Enter your real opening balances for cash, bank, e-wallet, and credit-card debt, or edit/add accounts.
2. Go to **Settings → Budgets**. Enter your monthly budget and optional extra protected reserve.
3. Use the **+** button to add income, expenses, and transfers.
4. Go to **Settings → Recurring bills** for monthly subscriptions and other repeating commitments.
5. Go to **Settings → Savings goals** to deposit or withdraw protected savings.
6. Open **Can I Afford This?** before a purchase for an explained, budget-based estimate.
7. Use **Settings → Data & privacy** to export a JSON backup. Use CSV exports for spreadsheet analysis.

For a test drive with fictional data, click **Settings → Data & privacy → Load sample data**. Samples **replace** local records; delete them before tracking real finances.

## Financial logic

- Monthly expense totals include **expense** transactions only. Income is counted separately.
- Transfers between cash, bank and e-wallet accounts do **not** increase spending or income.
- Moving money from an account into a savings goal is treated as a transfer out of spendable cash and into protected savings; moving it back reverses that movement.
- Credit-card purchases are expenses (they reduce the card's account balance / increase its debt); paying a card with your bank account is a transfer, **not** another expense.
- Recurring schedules are not expenses until you mark the payment as paid. Unpaid active bills in the current month are reserved in the affordability calculation but do not appear as recorded spending.
- The affordability tool uses the smallest of (a) non-credit account balances minus unpaid monthly bills and protected cash, (b) remaining monthly budget minus unpaid monthly bills, and (c) remaining category budget, if set. Buying an item must fit these limits to avoid a red result. A customizable buffer determines yellow versus green; needs use a smaller buffer than wants.
- The affordability result is a **budget estimate**, not an assertion that you can afford a purchase. Unrecorded expenses, card interest, late fees, and future months' commitments are not forecast.

## Data privacy and backups

Your data is saved in the browser's **localStorage** for this app's web origin. It does not leave your device, and there is no login or automatic synchronization between devices. The data is **not encrypted** at rest. You can lose data if you clear browser website data, use private/incognito browsing, or switch to a different website origin. Export a full **JSON backup** often, and use **Restore a backup** if needed.

This release does not connect to banks or send push reminders. Recurring payment indicators are shown in the app. You must enter transactions yourself.

## Folder structure

- `index.html` — page structure, navigation icon sprite, and app metadata
- `style.css` — responsive dark/light design
- `app.js` — state, calculations, visualizations and interactions
- `manifest.webmanifest` — installable web app metadata
- `sw.js` — app-shell offline cache for HTTPS/localhost
- `icons/` — PWA icons

## License

Provided for your personal use and modification.
